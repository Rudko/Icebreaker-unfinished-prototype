//
//  ProfileViewController.swift
//  IceBreaker Codepath
//
//  Created by Grigory Rudko on 11/22/16.
//  Copyright © 2016 Grigory Rudko. All rights reserved.
//

import UIKit
import AVFoundation


class ProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextViewDelegate, UIScrollViewDelegate   {
    
    //VIDEO BACKGROUND
    @IBOutlet weak var cameraView: UIView!
    
    @IBOutlet weak var profileTextView: UITextView!
    
    @IBOutlet weak var keyboardScrollView: UIScrollView!
    
    @IBOutlet var tabBarButtons: [UIButton]!
    @IBOutlet weak var topsButton: UIButton!
    
    // TOPS BUTTONS OUTLETS
    @IBOutlet weak var jacketButton: UIButton!
    @IBOutlet weak var tshirtButton: UIButton!
    
    // BOTTOMS BUTTONS OUTLETS
    @IBOutlet weak var jeansButton: UIButton!
    
    // SHOES BUTTONS OUTLETS
    @IBOutlet weak var sneakersButton: UIButton!
    
    // HAIR
    @IBOutlet weak var longHairButton: UIButton!
    
    // ACCESSORIES
    @IBOutlet weak var laptop: UIButton!
    @IBOutlet weak var backpack: UIButton!
    
    
    
    
    
    @IBOutlet weak var doneButton: UIButton!
    @IBOutlet weak var describeYourLookLabel: UILabel!
    @IBOutlet weak var colorsView: UIView!
    @IBOutlet weak var hairColorsView: UIView!
    
    
    
    var captureSession: AVCaptureSession?
    var stillImageOutput: AVCaptureStillImageOutput?
    var previewLayer: AVCaptureVideoPreviewLayer?
    
    //TAB BAR
    var selectedIndex: Int = 0
    var buttonInitialY: CGFloat!
    var buttonOffset: CGFloat!
    
    // TOPS
    var brownJacketButton: UIButton!
    var blackTshirtButton: UIButton!
    
    // BOTTOMS
    var greyJeansButton: UIButton!
    
    // SHOES
    var whiteSneakersButton: UIButton!
    
    // HAIR
    var longBlondHairButton: UIButton!
    
    // LAPTOP
    var laptopButton: UIButton!
    var blueBackpackButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        doneButton.isHidden = true
        
        // Text View
        profileTextView.text = "Tap here to enter your profile info..."
        profileTextView.backgroundColor = UIColor.white
        profileTextView.font = UIFont.systemFont(ofSize: 15)
        profileTextView.textColor = UIColor.lightGray
        profileTextView.font = UIFont.boldSystemFont(ofSize: 15)
        
        profileTextView.layer.cornerRadius = 5
        
        profileTextView.autocorrectionType = UITextAutocorrectionType.yes
        profileTextView.spellCheckingType = UITextSpellCheckingType.yes
        
        
        // KEYBOARD SCROLL VIEW
        self.keyboardScrollView.frame = CGRect(x: 0, y: 494, width:self.view.frame.width, height:self.view.frame.height)
        let keyboardScrollViewWidth:CGFloat = self.keyboardScrollView.frame.width
        let keyboardScrollViewHeight:CGFloat = self.keyboardScrollView.frame.height
        
        self.keyboardScrollView.contentSize = CGSize(width: 1875, height: 173)
        keyboardScrollView.delegate = self
        
        
        // INITIAL TAB BAR BUTTON
        tabBarButtons[selectedIndex].isSelected = true
        didPressTab(tabBarButtons[selectedIndex])
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        previewLayer?.frame = cameraView.bounds
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // COLORS & HAIR COLORS KEYBOARDS
        colorsView.center.y = 772
        hairColorsView.center.y = 772 + 210
        
        // Video Background
        captureSession = AVCaptureSession()
        captureSession?.sessionPreset = AVCaptureSessionPreset1920x1080
        
        let backCamera = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
        
        var error : NSError?
        var input: AVCaptureDeviceInput!
        do {
            input = try AVCaptureDeviceInput(device: backCamera)
        } catch let error1 as NSError {
            error = error1
            input = nil
        }
        
        if (error == nil && captureSession?.canAddInput(input) != nil){
            
            captureSession?.addInput(input)
            
            stillImageOutput = AVCaptureStillImageOutput()
            stillImageOutput?.outputSettings = [AVVideoCodecKey : AVVideoCodecJPEG]
            
            if (captureSession?.canAddOutput(stillImageOutput) != nil){
                captureSession?.addOutput(stillImageOutput)
                
                previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
                previewLayer?.videoGravity = AVLayerVideoGravityResizeAspect
                previewLayer?.connection.videoOrientation = AVCaptureVideoOrientation.portrait
                cameraView.layer.addSublayer(previewLayer!)
                captureSession?.startRunning()
                
            }
        }
    }
    
    
    
    //Selecting buttons when scrolling UIScrollView
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        let pageWidth = scrollView.frame.size.width
        let page = Int(round((scrollView.contentOffset.x ) / (pageWidth)))
        let previousIndex = selectedIndex
        tabBarButtons[previousIndex].isSelected = false
        
        selectedIndex = page
        tabBarButtons[page].isSelected = true
    }
    //    func scrollViewDidScroll(_ scrollView: UIScrollView) {
    //
    ////        print("scrollViewDidScroll")
    //        if keyboardScrollView.contentOffset == CGPoint(x: 0, y: keyboardScrollView.contentOffset.y) {
    //
    //            topsButton.isSelected = true
    //
    //        } else {
    //
    //            print("oi")
    //        }
    //
    //
    //    }
    
    // TextView: resign keyboard
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        
        if(text == "\n") {
            
            
            
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    
    // Placeholder text
    func textViewDidBeginEditing(_ textView: UITextView) {
        
        UIView.animate(withDuration: 0.2, delay: 0.2, options: .curveEaseOut, animations: {
            self.colorsView.center.y = 772
            
        }, completion: nil)
        
        
        if(textView.text == "Tap here to enter your profile info...") {
            
            
            textView.text = ""
        }
        
        textView.becomeFirstResponder()
    }
    
    
    func textViewDidEndEditing(_ textView: UITextView) {
        
        if(textView.text == "") {
            
            textView.text = "Tap here to enter your profile info..."
        }
        textView.resignFirstResponder()
    }
    
    
    
    // Tab Bar Buttons
    @IBAction func topsTabBarButton(_ sender: UIButton) {
        
        
        
        keyboardScrollView.setContentOffset(CGPoint(x: 0, y: keyboardScrollView.contentOffset.y), animated: true)
    }
    
    @IBAction func bottomsTabBarButton(_ sender: UIButton) {
        keyboardScrollView.setContentOffset(CGPoint(x: 375, y: keyboardScrollView.contentOffset.y), animated: true)
    }
    
    
    @IBAction func shoesTabBarButton(_ sender: UIButton) {
        
        keyboardScrollView.setContentOffset(CGPoint(x: 750, y: keyboardScrollView.contentOffset.y), animated: true)
    }
    
    
    @IBAction func hairTabBarButton(_ sender: UIButton) {
        keyboardScrollView.setContentOffset(CGPoint(x: 1125, y: keyboardScrollView.contentOffset.y), animated: true)
    }
    
    @IBAction func accessoriesTabBarButton(_ sender: UIButton) {
        keyboardScrollView.setContentOffset(CGPoint(x: 1500, y: keyboardScrollView.contentOffset.y), animated: true)
    }
    
    
    @IBAction func didPressTab(_ sender: UIButton) {
        
        let previousIndex = selectedIndex
        selectedIndex = sender.tag
        
        tabBarButtons[previousIndex].isSelected = false
        sender.isSelected = true
        
    }
    
    
    // BROWN JACKET
    @IBAction func jacket(_ sender: UIButton) {
        print("Jacket")
        jacketButton.isSelected = true
        
        
        UIView.animate(withDuration: 0.2, delay: 0.2, options: .curveEaseOut, animations: {
            self.colorsView.center.y = self.colorsView.center.y - self.colorsView.frame.height
            
        }, completion: nil)
    }
    
    //Creating a BROWN JACKET button for a new tag
    func setUpButton() {
        brownJacketButton = UIButton(type: .system)
        brownJacketButton.setImage(#imageLiteral(resourceName: "Brown jacket"), for: .normal)
        brownJacketButton.bounds = CGRect(x: 0, y: 0, width: 109, height: 33)
        brownJacketButton.center = CGPoint(x: 68, y: 295)
        brownJacketButton.tintColor = UIColor.white
        
        // NEXT
        brownJacketButton.addTarget(self, action: #selector(hideButton (sender:)), for: .touchUpInside)
        
        view.addSubview(brownJacketButton)
        
    }
    
    
    // Hide brownJacketButton
    @IBAction func hideButton(sender: UIButton!) {
        brownJacketButton.isHidden = true
        doneButton.isHidden = true
        describeYourLookLabel.isHidden = false
    }
    
    
    
    @IBAction func didPressBrownButton(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.2, delay: 0.3, options: .curveEaseOut, animations: {
            self.colorsView.center.y = 772
            
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveEaseOut, animations: {
            self.describeYourLookLabel.isHidden = true
        }, completion: nil)
        
        doneButton.isHidden = false
        
        
        if jacketButton.isSelected == true    {
            
            setUpButton()
            
        } else if tshirtButton.isSelected == true {
            print("tshirt")
        }
            
        else {
            print("hui")
        }
        
        
    }
    
    
    
    // BLACK TSHIRT
    @IBAction func didPressTShirtButton(_ sender: UIButton) {
        
        print("TShirt")
        tshirtButton.isSelected = true
        
        
        UIView.animate(withDuration: 0.2, delay: 0.2, options: .curveEaseOut, animations: {
            self.colorsView.center.y = self.colorsView.center.y - self.colorsView.frame.height
            
        }, completion: nil)
        
    }
    
    
    @IBAction func didPressBlackButton(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.2, delay: 0.3, options: .curveEaseOut, animations: {
            self.colorsView.center.y = 772
            
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveEaseOut, animations: {
            self.describeYourLookLabel.isHidden = true
        }, completion: nil)
        
        doneButton.isHidden = false
        
        setUpBlackTshirtButton()
    }
    
    // Set up BLACK TSHIRT button
    func setUpBlackTshirtButton() {
        blackTshirtButton = UIButton(type: .system)
        blackTshirtButton.setImage(#imageLiteral(resourceName: "black t-shirt-1"), for: .normal)
        blackTshirtButton.bounds = CGRect(x: 0, y: 0, width: 105, height: 33)
        blackTshirtButton.center = CGPoint(x: 14 + 109 + 12 + 52, y: 295)
        blackTshirtButton.tintColor = UIColor.white
        
        blackTshirtButton.addTarget(self, action: #selector(hideBlackTchirtButton (sender:)), for: .touchUpInside)
        
        view.addSubview(blackTshirtButton)
        
    }
    
    // Hide blackTshirtButton
    @IBAction func hideBlackTchirtButton(sender: UIButton!) {
        blackTshirtButton.isHidden = true
        //        doneButton.isHidden = true
        //        describeYourLookLabel.isHidden = false
    }
    
    
    
    
    // GREY JEANS
    
    @IBAction func didPressJeansButton(_ sender: UIButton) {
        print("Jeans")
        jeansButton.isSelected = true
        
        
        UIView.animate(withDuration: 0.2, delay: 0.2, options: .curveEaseOut, animations: {
            self.colorsView.center.y = self.colorsView.center.y - self.colorsView.frame.height
            
        }, completion: nil)
    }
    
    
    @IBAction func didPressGrey(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.2, delay: 0.3, options: .curveEaseOut, animations: {
            self.colorsView.center.y = 772
            
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveEaseOut, animations: {
            self.describeYourLookLabel.isHidden = true
        }, completion: nil)
        
        doneButton.isHidden = false
        
        setUpGreyJeansButton()
        
    }
    
    
    func setUpGreyJeansButton() {
        blackTshirtButton = UIButton(type: .system)
        blackTshirtButton.setImage(#imageLiteral(resourceName: "grey jeans-1"), for: .normal)
        blackTshirtButton.bounds = CGRect(x: 0, y: 0, width: 105, height: 33)
        blackTshirtButton.center = CGPoint(x: 14 + 109 + 12 + 104 + 12 + 49 + 1, y: 295)
        blackTshirtButton.tintColor = UIColor.white
        
        blackTshirtButton.addTarget(self, action: #selector(hideBlackTchirtButton (sender:)), for: .touchUpInside)
        
        view.addSubview(blackTshirtButton)
        
    }
    
    
    
    
    // WHITE SNEAKERS
    @IBAction func didPressSneakersButton(_ sender: UIButton) {
        
        print("Sneakers")
        sneakersButton.isSelected = true
        
        
        UIView.animate(withDuration: 0.2, delay: 0.2, options: .curveEaseOut, animations: {
            self.colorsView.center.y = self.colorsView.center.y - self.colorsView.frame.height
            
        }, completion: nil)
        
    }
    
    
    @IBAction func didPressWhite(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.2, delay: 0.3, options: .curveEaseOut, animations: {
            self.colorsView.center.y = 772
            
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveEaseOut, animations: {
            self.describeYourLookLabel.isHidden = true
        }, completion: nil)
        
        doneButton.isHidden = false
        
        setUpWhiteSneakersButton()
    }
    
    
    func setUpWhiteSneakersButton() {
        whiteSneakersButton = UIButton(type: .system)
        whiteSneakersButton.setImage(#imageLiteral(resourceName: "white sneakers"), for: .normal)
        whiteSneakersButton.bounds = CGRect(x: 0, y: 0, width: 125, height: 33)
        whiteSneakersButton.center = CGPoint(x: 14 + 62, y: 295 + 33 + 8)
        whiteSneakersButton.tintColor = UIColor.white
        
        view.addSubview(whiteSneakersButton)
        
    }
    
    
    
    // HAIR
    @IBAction func didPressLongHairButton(_ sender: UIButton) {
        
        print("Long Hair")
        longHairButton.isSelected = true
        
        
        UIView.animate(withDuration: 0.2, delay: 0.2, options: .curveEaseOut, animations: {
            self.hairColorsView.center.y = self.hairColorsView.center.y - 420
            
        }, completion: nil)
    }
    
    
    @IBAction func didPressBlondButton(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.2, delay: 0.3, options: .curveEaseOut, animations: {
            self.hairColorsView.center.y = 772 + 210
        }, completion: nil)
        
        
        
        UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveEaseOut, animations: {
            self.describeYourLookLabel.isHidden = true
        }, completion: nil)
        
        doneButton.isHidden = false
        
        setUpLongBlondHairButton()
        
    }
    
    
    func setUpLongBlondHairButton() {
        longBlondHairButton = UIButton(type: .system)
        longBlondHairButton.setImage( #imageLiteral(resourceName: "long blond hair"), for: .normal)
        longBlondHairButton.bounds = CGRect(x: 0, y: 0, width: 124, height: 33)
        longBlondHairButton.center = CGPoint(x: 14 + 124 + 12 + 62, y: 295 + 33 + 8)
        longBlondHairButton.tintColor = UIColor.white
        
        view.addSubview(longBlondHairButton)
        
        
    }
    
    
    
    // LAPTOP
    @IBAction func didPressLaptop(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveEaseOut, animations: {
            self.describeYourLookLabel.isHidden = true
        }, completion: nil)
        
        doneButton.isHidden = false
        print("laptop")
        setUpLaptopButton()
    }
    
    
    
    func setUpLaptopButton() {
        laptopButton = UIButton(type: .system)
        laptopButton.setImage(#imageLiteral(resourceName: "laptop"), for: .normal)
        laptopButton.bounds = CGRect(x: 0, y: 0, width: 63, height: 33)
        laptopButton.center = CGPoint(x: 14 + 124 + 12 + 124 + 12 + 31, y: 295 + 33 + 8)
        laptopButton.tintColor = UIColor.white
        
        view.addSubview(laptopButton)
        
    }
    
    
    // BACKPACK
    
    @IBAction func didPressBackpack(_ sender: UIButton) {
        
        print("Backpack")
        backpack.isSelected = true
        
        UIView.animate(withDuration: 0.2, delay: 0.2, options: .curveEaseOut, animations: {
            self.colorsView.center.y = self.colorsView.center.y - self.colorsView.frame.height
            
        }, completion: nil)
        
    }
    
    
    @IBAction func blueButton(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.2, delay: 0.3, options: .curveEaseOut, animations: {
            self.colorsView.center.y = 772
            
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveEaseOut, animations: {
            self.describeYourLookLabel.isHidden = true
        }, completion: nil)
        
        doneButton.isHidden = false
        
        setUpBlueBackpackButton()
        
    }
    
    
    func setUpBlueBackpackButton() {
        blueBackpackButton = UIButton(type: .system)
        blueBackpackButton.setImage(#imageLiteral(resourceName: "blue backpack"), for: .normal)
        blueBackpackButton.bounds = CGRect(x: 0, y: 0, width: 121, height: 33)
        blueBackpackButton.center = CGPoint(x: 14 + 62, y: 295 + 33 + 8 + 33 + 8)
        blueBackpackButton.tintColor = UIColor.white
        
        view.addSubview(blueBackpackButton)
        
    }
    
    
    
}







































