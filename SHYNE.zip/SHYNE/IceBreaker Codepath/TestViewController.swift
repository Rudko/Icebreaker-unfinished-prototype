//
//  TestViewController.swift
//  IceBreaker Codepath
//
//  Created by Grigory Rudko on 12/1/16.
//  Copyright © 2016 Grigory Rudko. All rights reserved.
//

import UIKit

class TestViewController: UIViewController, UITextViewDelegate, UITextFieldDelegate {

    @IBOutlet weak var testTextView: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()

        testTextView.text = "Tap here to enter your profile info..."
        testTextView.backgroundColor = UIColor.brown
        testTextView.font = UIFont.systemFont(ofSize: 15)
        testTextView.textColor = UIColor.lightGray
        testTextView.font = UIFont.boldSystemFont(ofSize: 15)
        
        testTextView.layer.cornerRadius = 5
        
        testTextView.autocorrectionType = UITextAutocorrectionType.yes
        testTextView.spellCheckingType = UITextSpellCheckingType.yes
    }
    
    // TextView: resign keyboard
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if(text == "\n") {
            
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    
    // Placeholder text
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if(textView.text == "Tap here to enter your profile info...") {
            
            textView.text = ""
        }
        
        textView.becomeFirstResponder()
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if(textView.text == "") {
            
            textView.text = "Tap here to enter your profile info..."
        }
        textView.resignFirstResponder()
    }

}
