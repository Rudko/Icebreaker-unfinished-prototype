//
//  StrangerViewController.swift
//  IceBreaker Codepath
//
//  Created by Grigory Rudko on 1/9/17.
//  Copyright © 2017 Grigory Rudko. All rights reserved.
//

import UIKit
import AVFoundation



class StrangerViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextViewDelegate, UIScrollViewDelegate {
    
    
    
    //VIDEO BACKGROUND
    @IBOutlet weak var cameraView: UIView!
    @IBOutlet weak var ageLabel: UILabel!
    
    
    
    @IBOutlet weak var doneButton: UIButton!
    @IBOutlet weak var describeYourLookLabel: UILabel!
    @IBOutlet var tabBarButtons: [UIButton]!
    
    @IBOutlet weak var keyboardScrollView: UIScrollView!
    
    @IBOutlet weak var colorsView: UIView!
    @IBOutlet weak var hairColorsView: UIView!
    

    
    //LOOK
    @IBOutlet weak var dressButton: UIButton!
    @IBOutlet weak var heelsButton: UIButton!
    @IBOutlet weak var bagButton: UIButton!
    @IBOutlet weak var longHairButton: UIButton!
    
    
    
    
    //VIDEO BACKGROUND
    var captureSession: AVCaptureSession?
    var stillImageOutput: AVCaptureStillImageOutput?
    var previewLayer: AVCaptureVideoPreviewLayer?
    
    //TAB BAR
    var selectedIndex: Int = 0
    var buttonInitialY: CGFloat!
    var buttonOffset: CGFloat!

    
    
    // LOOK
    var greenDressButton: UIButton!
    var longBrownHairButton: UIButton!
    var brownHeelsButton: UIButton!
    var sunglassesButton: UIButton!
    var brownBagButton: UIButton!
    
    override func viewDidLoad() {
        
        doneButton.isHidden = true
        
        // INITIAL TAB BAR BUTTON
        tabBarButtons[selectedIndex].isSelected = true
        didPressTab(tabBarButtons[selectedIndex])
        
        
        
        // KEYBOARD SCROLL VIEW
        self.keyboardScrollView.frame = CGRect(x: 0, y: 494, width:self.view.frame.width, height:self.view.frame.height)
        let keyboardScrollViewWidth:CGFloat = self.keyboardScrollView.frame.width
        let keyboardScrollViewHeight:CGFloat = self.keyboardScrollView.frame.height
        
        self.keyboardScrollView.contentSize = CGSize(width: 1875, height: 173)
        keyboardScrollView.delegate = self
        
    }
    
    
    // SELECTING BUTTONS WHEN SCROLLING UIScrollView
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        let pageWidth = scrollView.frame.size.width
        let page = Int(round((scrollView.contentOffset.x ) / (pageWidth)))
        let previousIndex = selectedIndex
        tabBarButtons[previousIndex].isSelected = false
        
        selectedIndex = page
        tabBarButtons[page].isSelected = true
    }
    
    
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        previewLayer?.frame = cameraView.bounds
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Video Background
        captureSession = AVCaptureSession()
        captureSession?.sessionPreset = AVCaptureSessionPreset1920x1080
        
        let backCamera = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
        
        var error : NSError?
        var input: AVCaptureDeviceInput!
        do {
            input = try AVCaptureDeviceInput(device: backCamera)
        } catch let error1 as NSError {
            error = error1
            input = nil
        }
        
        if (error == nil && captureSession?.canAddInput(input) != nil){
            
            captureSession?.addInput(input)
            
            stillImageOutput = AVCaptureStillImageOutput()
            stillImageOutput?.outputSettings = [AVVideoCodecKey : AVVideoCodecJPEG]
            
            if (captureSession?.canAddOutput(stillImageOutput) != nil){
                captureSession?.addOutput(stillImageOutput)
                
                previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
                previewLayer?.videoGravity = AVLayerVideoGravityResizeAspect
                previewLayer?.connection.videoOrientation = AVCaptureVideoOrientation.portrait
                cameraView.layer.addSublayer(previewLayer!)
                captureSession?.startRunning()
                
            }
        }
        
    }
    
    
    // TAB BAR BUTTONS
    
    @IBAction func topsTabBarButton(_ sender: UIButton) {
        
        
        
        keyboardScrollView.setContentOffset(CGPoint(x: 0, y: keyboardScrollView.contentOffset.y), animated: true)
    }
    
    @IBAction func bottomsTabBarButton(_ sender: UIButton) {
        keyboardScrollView.setContentOffset(CGPoint(x: 375, y: keyboardScrollView.contentOffset.y), animated: true)
    }
    
    
    @IBAction func shoesTabBarButton(_ sender: UIButton) {
        
        keyboardScrollView.setContentOffset(CGPoint(x: 750, y: keyboardScrollView.contentOffset.y), animated: true)
    }
    
    
    @IBAction func hairTabBarButton(_ sender: UIButton) {
        keyboardScrollView.setContentOffset(CGPoint(x: 1125, y: keyboardScrollView.contentOffset.y), animated: true)
    }
    
    @IBAction func accessoriesTabBarButton(_ sender: UIButton) {
        keyboardScrollView.setContentOffset(CGPoint(x: 1500, y: keyboardScrollView.contentOffset.y), animated: true)
    }
    
    @IBAction func didPressTab(_ sender: UIButton) {
        
        let previousIndex = selectedIndex
        selectedIndex = sender.tag
        
        tabBarButtons[previousIndex].isSelected = false
        sender.isSelected = true
        
    }
    
    
    // GREEN DRESS
    @IBAction func didPressDress(_ sender: UIButton) {
       
        print("Dress")
        dressButton.isSelected = true

        UIView.animate(withDuration: 0.2, delay: 0.2, options: .curveEaseOut, animations: {
            self.colorsView.center.y = self.colorsView.center.y - self.colorsView.frame.height
            
        }, completion: nil)
        
    }
    
    //Creating a GREEN DRESS button
    func setUpButton() {
        greenDressButton = UIButton(type: .system)
        greenDressButton.setImage(#imageLiteral(resourceName: "green dress@2xher"), for: .normal)
        greenDressButton.bounds = CGRect(x: 0, y: 0, width: 103, height: 33)
        greenDressButton.center = CGPoint(x: 14  + 51, y: 295)
        greenDressButton.tintColor = UIColor.white
        

        greenDressButton.addTarget(self, action: #selector(hideButton (sender:)), for: .touchUpInside)
        
        view.addSubview(greenDressButton)
        
    }
    
    
    @IBAction func didPressGreenButton(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.2, delay: 0.3, options: .curveEaseOut, animations: {
            self.colorsView.center.y = 772
            
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveEaseOut, animations: {
            self.describeYourLookLabel.isHidden = true
        }, completion: nil)
        
        doneButton.isHidden = false
        
        
        if dressButton.isSelected == true    {
            
            setUpButton()
            
        } else {
            print("hui")
        }
        
        
    }
    
    
    // Hide GREEN DRESS button
    @IBAction func hideButton(sender: UIButton!) {
        greenDressButton.isHidden = true
        doneButton.isHidden = true
        describeYourLookLabel.isHidden = false
    }
    
    
    // LONG DARK HAIR
    
    @IBAction func didPressLongHairButton(_ sender: UIButton) {
        
        print("Long Hair")
        longHairButton.isSelected = true
        
        
        UIView.animate(withDuration: 0.2, delay: 0.2, options: .curveEaseOut, animations: {
            self.hairColorsView.center.y = self.hairColorsView.center.y - 420
            
        }, completion: nil)
    }
    
    
    @IBAction func didPressBrownHairButton(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.2, delay: 0.3, options: .curveEaseOut, animations: {
            self.hairColorsView.center.y = 772 + 210
        }, completion: nil)
        
        
        
        UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveEaseOut, animations: {
            self.describeYourLookLabel.isHidden = true
        }, completion: nil)
        
        doneButton.isHidden = false
        
        setUpLongBrownHairButton()
        
    }
    
    
    func setUpLongBrownHairButton() {
        longBrownHairButton = UIButton(type: .system)
        longBrownHairButton.setImage(#imageLiteral(resourceName: "long brown hair@2xher-1"), for: .normal)
        longBrownHairButton.bounds = CGRect(x: 0, y: 0, width: 128, height: 33)
        longBrownHairButton.center = CGPoint(x: 12 + 103 + 12 + 64, y: 295)
        longBrownHairButton.tintColor = UIColor.white
        
        view.addSubview(longBrownHairButton)
        
        
    }

    
    
    
    
    // BROWN HEELS
    
    @IBAction func didPressHeelsButton(_ sender: UIButton) {
        
        print("Heels")
        heelsButton.isSelected = true
        
        
        UIView.animate(withDuration: 0.2, delay: 0.2, options: .curveEaseOut, animations: {
            self.colorsView.center.y = self.colorsView.center.y - self.colorsView.frame.height
            
        }, completion: nil)
        
    }
    
    
    @IBAction func didPressBrown(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.2, delay: 0.3, options: .curveEaseOut, animations: {
            self.colorsView.center.y = 772
            
        }, completion: nil)
        
        
        
        UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveEaseOut, animations: {
            self.describeYourLookLabel.isHidden = true
        }, completion: nil)
        
        doneButton.isHidden = false
        
        if bagButton.isSelected == true {
            setUpBrownBagButton()
        } else {
        setUpBrownHeelsButton()
    }
    }
    
    func setUpBrownHeelsButton() {
        brownHeelsButton = UIButton(type: .system)
        brownHeelsButton.setImage(#imageLiteral(resourceName: "brown heels@2xher"), for: .normal)
        brownHeelsButton.bounds = CGRect(x: 0, y: 0, width: 105, height: 33)
        brownHeelsButton.center = CGPoint(x: 12 + 97 + 12 + 52, y: 295 + 33 + 8)
        brownHeelsButton.tintColor = UIColor.white
        
        view.addSubview(brownHeelsButton)
        
    }

    
    // SUNGLASSES
    @IBAction func didPressSunglasses(_ sender: UIButton) {
        
        print("Sunglasses")
        
        doneButton.isHidden = false
        
        setUpSunglassesButton()

    }
    
    
    
    func setUpSunglassesButton() {
    
    sunglassesButton = UIButton(type: .system)
    sunglassesButton.setImage(#imageLiteral(resourceName: "sunglasses@2xher"), for: .normal)
    sunglassesButton.bounds = CGRect(x: 0, y: 0, width: 97, height: 33)
    sunglassesButton.center = CGPoint(x: 12 + 49, y: 295 + 8 + 33)
    sunglassesButton.tintColor = UIColor.white
    
    view.addSubview(sunglassesButton)

    
    }
    
        // BROWN BAG

    @IBAction func didPressBagButton(_ sender: UIButton) {
        
        print("Bag")
        bagButton.isSelected = true
        
        
        UIView.animate(withDuration: 0.2, delay: 0.2, options: .curveEaseOut, animations: {
            self.colorsView.center.y = self.colorsView.center.y - self.colorsView.frame.height
            
        }, completion: nil)
        
    }
    
    func setUpBrownBagButton() {
        
        brownBagButton = UIButton(type: .system)
        brownBagButton.setImage(#imageLiteral(resourceName: "brown bag@2xher"), for: .normal)
        brownBagButton.bounds = CGRect(x: 0, y: 0, width: 94, height: 33)
        brownBagButton.center = CGPoint(x: 12 + 103 + 12 + 128 + 12 + 47, y: 295)
        brownBagButton.tintColor = UIColor.white
        
        view.addSubview(brownBagButton)
        
        
    }
    
    
    
    
    
}































