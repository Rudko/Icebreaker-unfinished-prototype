//
//  StrangerViewController.swift
//  IceBreaker Codepath
//
//  Created by Grigory Rudko on 1/9/17.
//  Copyright © 2017 Grigory Rudko. All rights reserved.
//

import Foundation
